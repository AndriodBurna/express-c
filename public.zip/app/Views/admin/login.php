<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Admin Login | Ephraitech</title>
<link rel="icon" type="image/svg+xml" href="<?= base_url('assets/images/favicon.svg') ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="<?= base_url('assets/css/admin.css') ?>">
</head>
<body class="admin admin-login">
  <div class="login-wrap">
    <div class="login-card">
      <div class="login-brand">
        <img src="<?= base_url('assets/images/logo%20no%20bg.png') ?>" alt="Ephraitech" width="180" height="48">
        <h1>Admin Panel</h1>
        <p>Sign in to manage your website.</p>
      </div>

      <?php if (!empty($error)): ?>
        <div class="alert alert-error"><i class="fa-solid fa-triangle-exclamation"></i> <?= e($error) ?></div>
      <?php endif; ?>

      <form method="post" action="<?= base_url('control/login') ?>">
        <?= csrf_field() ?>
        <div class="form-group">
          <label class="form-label" for="username">Username</label>
          <input class="form-control" id="username" name="username" type="text" required autofocus autocomplete="username">
        </div>
        <div class="form-group">
          <label class="form-label" for="password">Password</label>
          <input class="form-control" id="password" name="password" type="password" required autocomplete="current-password">
        </div>
        <button type="submit" class="btn btn-primary btn-block">Sign In <i class="fa-solid fa-arrow-right"></i></button>
      </form>

      <p class="login-help"><a href="<?= base_url('/') ?>">&larr; Back to website</a></p>
    </div>
  </div>
</body>
</html>