<?= $this->extend('layouts/admin') ?>

<?= $this->section('content') ?>

<div class="card">
  <div class="card-header">
    <h2>Quote Request #<?= (int) $quote['id'] ?></h2>
    <a class="btn btn-outline btn-sm" href="<?= base_url('control/quotes') ?>">
      <i class="fa-solid fa-arrow-left"></i> Back to Quotes
    </a>
  </div>

  <div style="padding:1.5rem">

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:1.25rem;margin-bottom:1.75rem">
      <div>
        <small style="display:block;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;color:#888">From</small>
        <strong><?= e($quote['first_name'] . ' ' . $quote['last_name']) ?></strong>
      </div>
      <div>
        <small style="display:block;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;color:#888">Email</small>
        <a href="mailto:<?= e($quote['email']) ?>"><?= e($quote['email']) ?></a>
      </div>
      <?php if (!empty($quote['phone'])): ?>
        <div>
          <small style="display:block;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;color:#888">Phone</small>
          <a href="tel:<?= e($quote['phone']) ?>"><?= e($quote['phone']) ?></a>
        </div>
      <?php endif; ?>
      <?php if (!empty($quote['whatsapp'])): ?>
        <div>
          <small style="display:block;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;color:#888">WhatsApp</small>
          <a href="https://wa.me/<?= e(ltrim(preg_replace('/[^0-9+]/', '', $quote['whatsapp']), '+')) ?>" target="_blank" rel="noopener"><?= e($quote['whatsapp']) ?></a>
        </div>
      <?php endif; ?>
      <?php if (!empty($quote['company'])): ?>
        <div>
          <small style="display:block;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;color:#888">Company</small>
          <?= e($quote['company']) ?>
        </div>
      <?php endif; ?>
      <?php if (!empty($quote['service_needed'])): ?>
        <div>
          <small style="display:block;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;color:#888">Service</small>
          <?= e($quote['service_needed']) ?>
        </div>
      <?php endif; ?>
      <?php if (!empty($quote['budget'])): ?>
        <div>
          <small style="display:block;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;color:#888">Budget</small>
          <?= e($quote['budget']) ?>
        </div>
      <?php endif; ?>
      <div>
        <small style="display:block;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;color:#888">Received</small>
        <?= e(date('d M Y, H:i', strtotime($quote['created_at']))) ?>
      </div>
      <?php if (!empty($quote['ip_address'])): ?>
        <div>
          <small style="display:block;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;color:#888">IP Address</small>
          <?= e($quote['ip_address']) ?>
        </div>
      <?php endif; ?>
      <div>
        <small style="display:block;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;color:#888">Status</small>
        <span class="badge <?= e($quote['status'] ?? 'new') ?>"><?= e(str_replace('_', ' ', $quote['status'] ?? 'new')) ?></span>
      </div>
    </div>

    <hr style="border:0;border-top:1px solid #eee;margin:1.5rem 0">

    <h3 style="margin:0 0 .75rem;font-size:1rem">Project Description</h3>
    <div style="white-space:pre-wrap;line-height:1.7;color:#333"><?= e($quote['description']) ?></div>

    <hr style="border:0;border-top:1px solid #eee;margin:1.75rem 0">

    <h3 style="margin:0 0 .75rem;font-size:1rem">Update Status</h3>
    <form method="post" action="<?= base_url('control/quotes/status') ?>" style="display:flex;gap:.6rem;align-items:center;flex-wrap:wrap">
      <?= csrf_field() ?>
      <input type="hidden" name="id" value="<?= (int) $quote['id'] ?>">
      <select name="status" class="form-control" style="max-width:220px">
        <?php foreach ($statuses as $s): ?>
          <option value="<?= $s ?>" <?= ($quote['status'] ?? '') === $s ? 'selected' : '' ?>>
            <?= ucwords(str_replace('_', ' ', $s)) ?>
          </option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn btn-primary">Save Status</button>
    </form>

    <div style="margin-top:2rem;display:flex;gap:.6rem;flex-wrap:wrap">
      <a class="btn btn-primary" href="mailto:<?= e($quote['email']) ?>?subject=Re: Your quote request">
        <i class="fa-solid fa-reply"></i> Reply by Email
      </a>

      <form method="post" action="<?= base_url('control/quotes/delete') ?>" style="display:inline" data-confirm="Delete this quote request permanently?">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= (int) $quote['id'] ?>">
        <button class="btn btn-danger" type="submit">
          <i class="fa-solid fa-trash"></i> Delete Quote
        </button>
      </form>
    </div>

  </div>
</div>

<?= $this->endSection() ?>